package com.example.studenthub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {
    private EditText emailInput, passwordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        Button loginButton = findViewById(R.id.loginButton);
        Button registerButton = findViewById(R.id.registerButton);
        TextView forgotLink = findViewById(R.id.forgotLink);

        loginButton.setOnClickListener(v -> login());
        registerButton.setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class)));
        forgotLink.setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class)));
    }

    private void login() {
        String email = emailInput.getText().toString().trim().toLowerCase();
        String password = passwordInput.getText().toString();

        if (email.isEmpty()) {
            emailInput.setError("Please enter your email");
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInput.setError("Enter a valid email address");
            return;
        }
        if (password.isEmpty()) {
            passwordInput.setError("Please enter your password");
            return;
        }

        boolean demoLogin = email.equals("student@example.com") && password.equals("123456");
        boolean registeredLogin = email.equals(Prefs.getEmail(this)) && password.equals(Prefs.getPassword(this));

        if (demoLogin || registeredLogin) {
            String name = demoLogin ? "Demo Student" : Prefs.getName(this);
            Prefs.setSession(this, name, email);
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Incorrect email or password. Use the demo account or register first.", Toast.LENGTH_LONG).show();
        }
    }
}
