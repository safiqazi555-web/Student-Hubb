package com.example.studenthub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ForgotPasswordActivity extends Activity {
    private EditText emailInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        emailInput = findViewById(R.id.emailInput);
        Button recoverButton = findViewById(R.id.recoverButton);
        TextView backToLogin = findViewById(R.id.backToLogin);

        recoverButton.setOnClickListener(v -> recover());
        backToLogin.setOnClickListener(v -> finish());
    }

    private void recover() {
        String email = emailInput.getText().toString().trim().toLowerCase();
        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInput.setError("Enter a valid email address");
            return;
        }

        Prefs.setRecoveryEmail(this, email);
        Toast.makeText(this, "Demo recovery request accepted. No real email was sent.", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(ForgotPasswordActivity.this, ResetPasswordActivity.class);
        startActivity(intent);
    }
}
