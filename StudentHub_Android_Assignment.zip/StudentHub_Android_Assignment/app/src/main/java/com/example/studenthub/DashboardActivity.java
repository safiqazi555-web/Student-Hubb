package com.example.studenthub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class DashboardActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        TextView welcomeText = findViewById(R.id.welcomeText);
        welcomeText.setText("Welcome, " + Prefs.getSessionName(this) + "!");

        findViewById(R.id.profileCard).setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, ProfileActivity.class)));

        findViewById(R.id.coursesCard).setOnClickListener(v ->
                Toast.makeText(this, "Courses module selected (demo)", Toast.LENGTH_SHORT).show());
        findViewById(R.id.attendanceCard).setOnClickListener(v ->
                Toast.makeText(this, "Attendance module selected (demo)", Toast.LENGTH_SHORT).show());
        findViewById(R.id.assignmentsCard).setOnClickListener(v ->
                Toast.makeText(this, "Assignments module selected (demo)", Toast.LENGTH_SHORT).show());
    }

    @Override
    protected void onResume() {
        super.onResume();
        TextView welcomeText = findViewById(R.id.welcomeText);
        if (welcomeText != null) {
            welcomeText.setText("Welcome, " + Prefs.getSessionName(this) + "!");
        }
    }
}
