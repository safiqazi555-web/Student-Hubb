package com.example.studenthub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ResetPasswordActivity extends Activity {
    private EditText newPasswordInput, confirmPasswordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        newPasswordInput = findViewById(R.id.newPasswordInput);
        confirmPasswordInput = findViewById(R.id.confirmPasswordInput);
        Button saveButton = findViewById(R.id.savePasswordButton);

        saveButton.setOnClickListener(v -> savePassword());
    }

    private void savePassword() {
        String password = newPasswordInput.getText().toString();
        String confirm = confirmPasswordInput.getText().toString();

        if (password.length() < 6) {
            newPasswordInput.setError("Password must be at least 6 characters");
            return;
        }
        if (!password.equals(confirm)) {
            confirmPasswordInput.setError("Passwords do not match");
            return;
        }

        String email = Prefs.getRecoveryEmail(this);
        if (email.equals(Prefs.getEmail(this)) || email.equals("student@example.com")) {
            Prefs.saveUser(this, Prefs.getName(this), email, password);
        }

        Toast.makeText(this, "Password reset simulated successfully. Please login.", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(ResetPasswordActivity.this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}
