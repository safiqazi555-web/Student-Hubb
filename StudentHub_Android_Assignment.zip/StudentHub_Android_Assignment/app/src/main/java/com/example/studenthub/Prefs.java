package com.example.studenthub;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    private static final String FILE = "studenthub_data";

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static void saveUser(Context context, String name, String email, String password) {
        prefs(context).edit()
                .putString("user_name", name)
                .putString("user_email", email.toLowerCase().trim())
                .putString("user_password", password)
                .apply();
    }

    public static String getName(Context context) {
        return prefs(context).getString("user_name", "Student");
    }

    public static String getEmail(Context context) {
        return prefs(context).getString("user_email", "student@example.com");
    }

    public static String getPassword(Context context) {
        return prefs(context).getString("user_password", "123456");
    }

    public static void setRecoveryEmail(Context context, String email) {
        prefs(context).edit().putString("recovery_email", email.toLowerCase().trim()).apply();
    }

    public static String getRecoveryEmail(Context context) {
        return prefs(context).getString("recovery_email", "");
    }

    public static void setSession(Context context, String name, String email) {
        prefs(context).edit()
                .putString("session_name", name)
                .putString("session_email", email)
                .putBoolean("logged_in", true)
                .apply();
    }

    public static String getSessionName(Context context) {
        return prefs(context).getString("session_name", getName(context));
    }

    public static String getSessionEmail(Context context) {
        return prefs(context).getString("session_email", getEmail(context));
    }

    public static void logout(Context context) {
        prefs(context).edit().remove("session_name").remove("session_email")
                .putBoolean("logged_in", false).apply();
    }
}
