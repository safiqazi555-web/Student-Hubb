package com.example.studenthub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class ProfileActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        TextView profileName = findViewById(R.id.profileName);
        TextView profileEmail = findViewById(R.id.profileEmail);
        Button backButton = findViewById(R.id.backDashboardButton);
        Button logoutButton = findViewById(R.id.logoutButton);

        profileName.setText(Prefs.getSessionName(this));
        profileEmail.setText(Prefs.getSessionEmail(this));

        backButton.setOnClickListener(v -> finish());
        logoutButton.setOnClickListener(v -> {
            Prefs.logout(this);
            Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }
}
