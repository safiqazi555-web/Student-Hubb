# Assignment 2 Submission Guide

## Suggested document order
1. Title page: course, assignment title, student name, registration number, and section.
2. Source-code screenshots:
   - SplashActivity.java and activity_splash.xml
   - LoginActivity.java and activity_login.xml
   - RegisterActivity.java and activity_register.xml
   - DashboardActivity.java and activity_dashboard.xml
   - ProfileActivity.java and activity_profile.xml
   - strings.xml, default colors.xml, and values-night/colors.xml
3. App output screenshots:
   - Splash
   - Login
   - Register
   - Forgot Password
   - Reset Password
   - Dashboard
   - Profile
4. GitHub repository screenshot.
5. Clickable GitHub repository URL.

## GitHub upload
1. Sign in to GitHub and create a repository, for example `StudentHub-Android-App`.
2. Upload the extracted project folder's contents. Make sure `settings.gradle`, `build.gradle`, `app/`, and `README.md` are included.
3. Open the repository in a browser and copy its URL.
4. Add the URL to the submission document.

Do not claim the project is on GitHub until you have actually uploaded it. The assignment sheet's page limit was not specified in the provided text, so confirm it with your instructor.
